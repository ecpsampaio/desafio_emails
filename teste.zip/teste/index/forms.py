from django import forms
from .models import *

class CountryForm(forms.ModelForm):
    class Meta:
        model = Country
        fields = ('country',)


class DomainForm(forms.ModelForm):
    class Meta:
        model = Domain
        fields = ('domain','country',)
        

class EmailForm(forms.ModelForm):
    class Meta:
        model = Email
        fields = ('email','domain','country',)
