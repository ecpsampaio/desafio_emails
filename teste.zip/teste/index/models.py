from django.db import models

class Country(models.Model):
    country = models.CharField(max_length=100,unique=True )
    date = models.DateTimeField(auto_now_add=True )

    class Meta :
        verbose_name = 'country'
        verbose_name_plural = 'countries'
        ordering = ['-date']

    def __str__ ( self ) :
        return self.country

class Domain( models.Model ) :
    domain = models.CharField (max_length=100,unique=True)   
    country = models.ForeignKey(Country,on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True )

    class Meta :
        verbose_name = 'domain'
        verbose_name_plural = 'domains'
        ordering = ['-date']

    def __str__ ( self ) :
        return self.domain

class Email ( models.Model ) :
    email = models.EmailField(max_length=100,unique=True)
    domain = models.ForeignKey ( Domain , on_delete=models.CASCADE )
    country = models.ForeignKey(Country,on_delete=models.CASCADE)
    date = models.DateTimeField (auto_now_add=True)

    class Meta :
        verbose_name = 'email'
        verbose_name_plural = 'emails'
        ordering = ['-date']
    
    @property
    def email_domain(self):
        return ''.join(self.email.split('@')[1]).lower()

    def __str__ ( self ) :
        return self.email
